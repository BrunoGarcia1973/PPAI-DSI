package dsi.ppai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PpaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
